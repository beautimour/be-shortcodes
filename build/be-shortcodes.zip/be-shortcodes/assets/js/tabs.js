( function( $ ) {

	$( function() {
		$( '.be-tabs' ).tabs();
	} );

}( jQuery ) );
